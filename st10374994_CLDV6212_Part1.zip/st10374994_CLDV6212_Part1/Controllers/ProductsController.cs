﻿using Azure;
using Azure.Data.Tables;
using Microsoft.AspNetCore.Mvc;
using st10374994_CLDV6212_Part1.Models;

namespace st10374994_CLDV6212_Part1.Controllers
{
    public class ProductsController : Controller
    {
        private readonly string _connectionString;
        private readonly string _tableName = "CustomerProducts";

        public ProductsController(IConfiguration configuration)
        {
            _connectionString = configuration["AzureStorage:ConnectionString"];
        }

        // READ - Show all products
        public IActionResult Index()
        {
            var tableClient = new TableClient(_connectionString, _tableName);
            var products = tableClient.Query<ProductEntity>(p => p.PartitionKey == "Product").ToList();
            return View(products);
        }

        // DETAILS
        public IActionResult Details(string id)
        {
            if (string.IsNullOrEmpty(id)) return NotFound();

            var tableClient = new TableClient(_connectionString, _tableName);
            var product = tableClient.GetEntity<ProductEntity>("Product", id).Value;

            return View(product);
        }

        // CREATE - Show form
        public IActionResult Create()
        {
            return View();
        }

        // CREATE - Save to Azure Table
        [HttpPost]
        public IActionResult Create(ProductEntity product)
        {
            product.PartitionKey = "Product";
            product.RowKey = Guid.NewGuid().ToString();

            var tableClient = new TableClient(_connectionString, _tableName);
            tableClient.AddEntity(product);

            return RedirectToAction(nameof(Index));
        }

        // EDIT - Show form
        public IActionResult Edit(string id)
        {
            if (string.IsNullOrEmpty(id)) return NotFound();

            var tableClient = new TableClient(_connectionString, _tableName);
            var product = tableClient.GetEntity<ProductEntity>("Product", id).Value;

            return View(product);
        }

        // EDIT - Save changes
        [HttpPost]
        public IActionResult Edit(ProductEntity product)
        {
            var tableClient = new TableClient(_connectionString, _tableName);
            tableClient.UpdateEntity(product, ETag.All, TableUpdateMode.Replace);

            return RedirectToAction(nameof(Index));
        }

        // DELETE - Show confirmation
        public IActionResult Delete(string id)
        {
            if (string.IsNullOrEmpty(id)) return NotFound();

            var tableClient = new TableClient(_connectionString, _tableName);
            var product = tableClient.GetEntity<ProductEntity>("Product", id).Value;

            return View(product);
        }

        // DELETE - Confirm removal
        [HttpPost, ActionName("Delete")]
        public IActionResult DeleteConfirmed(string id)
        {
            var tableClient = new TableClient(_connectionString, _tableName);
            tableClient.DeleteEntity("Product", id);

            return RedirectToAction(nameof(Index));
        }
    }
}
