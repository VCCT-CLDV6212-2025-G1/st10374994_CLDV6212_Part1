﻿using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Microsoft.AspNetCore.Mvc;
using st10374994_CLDV6212_Part1.Models;

namespace st10374994_CLDV6212_Part1.Controllers
{
    public class BlobController : Controller
    {
        private readonly string _connectionString;
        private readonly string _containerName = "productimages"; // must match Azure container name

        public BlobController(IConfiguration configuration)
        {
            _connectionString = configuration["AzureStorage:ConnectionString"] ?? string.Empty;
        }

        // Show all blobs
        public IActionResult Index()
        {
            var blobServiceClient = new BlobServiceClient(_connectionString);
            var containerClient = blobServiceClient.GetBlobContainerClient(_containerName);
            containerClient.CreateIfNotExists(PublicAccessType.Blob);

            var blobs = new List<BlobModel>();

            foreach (var blobItem in containerClient.GetBlobs())
            {
                blobs.Add(new BlobModel
                {
                    FileName = blobItem.Name,
                    BlobUrl = containerClient.GetBlobClient(blobItem.Name).Uri.ToString()
                });
            }

            return View(blobs);
        }

        // Upload new blob
        [HttpPost]
        public IActionResult Upload(IFormFile file)
        {
            if (file != null && file.Length > 0)
            {
                var blobServiceClient = new BlobServiceClient(_connectionString);
                var containerClient = blobServiceClient.GetBlobContainerClient(_containerName);
                containerClient.CreateIfNotExists(PublicAccessType.Blob);

                var blobClient = containerClient.GetBlobClient(file.FileName);
                using (var stream = file.OpenReadStream())
                {
                    blobClient.Upload(stream, overwrite: true);
                }
            }
            return RedirectToAction(nameof(Index));
        }

        // Delete blob
        public IActionResult Delete(string fileName)
        {
            if (string.IsNullOrWhiteSpace(fileName)) return RedirectToAction(nameof(Index));

            var blobServiceClient = new BlobServiceClient(_connectionString);
            var containerClient = blobServiceClient.GetBlobContainerClient(_containerName);

            var blobClient = containerClient.GetBlobClient(fileName);
            blobClient.DeleteIfExists();

            return RedirectToAction(nameof(Index));
        }
    }
}
