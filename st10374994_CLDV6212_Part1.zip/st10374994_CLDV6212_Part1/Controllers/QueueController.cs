﻿using Azure.Storage.Queues;
using Azure.Storage.Queues.Models;
using Microsoft.AspNetCore.Mvc;
using st10374994_CLDV6212_Part1.Models;
using QueueMessage = st10374994_CLDV6212_Part1.Models.QueueMessage;

namespace st10374994_CLDV6212_Part1.Controllers
{
    public class QueueController : Controller
    {
        private readonly string _connectionString;
        private readonly string _queueName = "ordersqueue";

        public QueueController(IConfiguration configuration)
        {
            _connectionString = configuration["AzureStorage:ConnectionString"] ?? string.Empty;
        }

        // Show messages
        public IActionResult Index()
        {
            var queueClient = new QueueClient(_connectionString, _queueName);
            queueClient.CreateIfNotExists();

            var messages = new List<QueueMessage>();

            // Peek top 10 messages
            var peekedMessages = queueClient.PeekMessages(maxMessages: 10);

            foreach (var msg in peekedMessages.Value)
            {
                messages.Add(new QueueMessage
                {
                    MessageId = msg.MessageId,
                    MessageText = msg.MessageText,
                    InsertionTime = msg.InsertedOn
                });
            }

            return View(messages);
        }

        // Add message
        [HttpPost]
        public IActionResult Send(string messageText)
        {
            if (!string.IsNullOrWhiteSpace(messageText))
            {
                var queueClient = new QueueClient(_connectionString, _queueName);
                queueClient.CreateIfNotExists();
                queueClient.SendMessage(messageText);
            }

            return RedirectToAction(nameof(Index));
        }

        // Delete single message
        public IActionResult Delete()
        {
            var queueClient = new QueueClient(_connectionString, _queueName);
            queueClient.CreateIfNotExists();

            // Retrieve and delete the next message (FIFO)
            var msg = queueClient.ReceiveMessage();
            if (msg.Value != null)
            {
                queueClient.DeleteMessage(msg.Value.MessageId, msg.Value.PopReceipt);
            }

            return RedirectToAction(nameof(Index));
        }

        // Delete all messages
        public IActionResult Clear()
        {
            var queueClient = new QueueClient(_connectionString, _queueName);
            queueClient.ClearMessages();
            return RedirectToAction(nameof(Index));
        }
    }
}