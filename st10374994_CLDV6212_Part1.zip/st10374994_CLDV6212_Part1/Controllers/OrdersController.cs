﻿using Azure.Data.Tables;
using Azure.Storage.Queues;
using Microsoft.AspNetCore.Mvc;
using st10374994_CLDV6212_Part1.Models;

namespace st10374994_CLDV6212_Part1.Controllers
{
    public class OrdersController : Controller
    {
        private readonly string _connectionString;
        private readonly string _tableName = "CustomerProducts"; // Orders use PartitionKey = "Order"
        private readonly string _queueName = "ordersqueue";

        public OrdersController(IConfiguration configuration)
        {
            _connectionString = configuration["AzureStorage:ConnectionString"] ?? string.Empty;
        }

        // GET: /Orders
        public IActionResult Index()
        {
            var table = new TableClient(_connectionString, _tableName);
            table.CreateIfNotExists();

            var orders = table.Query<Order>(o => o.PartitionKey == "Order").ToList();
            return View(orders);
        }

        // GET: /Orders/Details/{id}
        public IActionResult Details(string id)
        {
            if (string.IsNullOrWhiteSpace(id)) return RedirectToAction(nameof(Index));

            var table = new TableClient(_connectionString, _tableName);
            var order = table.GetEntity<Order>("Order", id).Value;

            return View(order);
        }

        // GET: /Orders/Create
        public IActionResult Create()
        {
            return View(new Order { OrderDate = DateTime.UtcNow, Status = "Pending" });
        }

        // POST: /Orders/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Order order)
        {
            if (!ModelState.IsValid)
                return View(order);

            order.PartitionKey = "Order";
            if (string.IsNullOrWhiteSpace(order.RowKey))
                order.RowKey = Guid.NewGuid().ToString();

            var table = new TableClient(_connectionString, _tableName);
            table.CreateIfNotExists();
            table.AddEntity(order);

            var queue = new QueueClient(_connectionString, _queueName);
            queue.CreateIfNotExists();
            var msg = $"NewOrder|Id:{order.RowKey}|Customer:{order.CustomerName}|Product:{order.ProductName}|Qty:{order.Quantity}|Date:{order.OrderDate:yyyy-MM-dd}|Status:{order.Status}";
            queue.SendMessage(msg);

            return RedirectToAction(nameof(Index));
        }

        // GET: /Orders/Edit/{id}
        public IActionResult Edit(string id)
        {
            if (string.IsNullOrWhiteSpace(id)) return RedirectToAction(nameof(Index));

            var table = new TableClient(_connectionString, _tableName);
            var order = table.GetEntity<Order>("Order", id).Value;

            return View(order);
        }

        // POST: /Orders/Edit/{id}
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(string id, Order updatedOrder)
        {
            if (!ModelState.IsValid)
                return View(updatedOrder);

            var table = new TableClient(_connectionString, _tableName);

            updatedOrder.PartitionKey = "Order";
            updatedOrder.RowKey = id;

            table.UpsertEntity(updatedOrder);

            return RedirectToAction(nameof(Index));
        }

        // GET: /Orders/Delete/{id}
        public IActionResult Delete(string id)
        {
            if (string.IsNullOrWhiteSpace(id)) return RedirectToAction(nameof(Index));

            var table = new TableClient(_connectionString, _tableName);
            var order = table.GetEntity<Order>("Order", id).Value;

            return View(order);
        }

        // POST: /Orders/Delete/{id}
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(string id)
        {
            var table = new TableClient(_connectionString, _tableName);
            table.DeleteEntity("Order", id);

            return RedirectToAction(nameof(Index));
        }
    }
}
