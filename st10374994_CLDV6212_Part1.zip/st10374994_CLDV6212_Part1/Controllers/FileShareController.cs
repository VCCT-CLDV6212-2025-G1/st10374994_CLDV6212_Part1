﻿using Azure.Storage.Files.Shares;
using Microsoft.AspNetCore.Mvc;
using st10374994_CLDV6212_Part1.Models;

namespace st10374994_CLDV6212_Part1.Controllers
{
    public class FileShareController : Controller
    {
        private readonly string _connectionString;
        private readonly string _shareName = "fileshare";

        public FileShareController(IConfiguration configuration)
        {
            _connectionString = configuration["AzureStorage:ConnectionString"] ?? string.Empty;
        }

        // GET: /FileShare
        public IActionResult Index()
        {
            var shareClient = new ShareClient(_connectionString, _shareName);
            shareClient.CreateIfNotExists();

            var directory = shareClient.GetRootDirectoryClient();
            var files = new List<FileShareModel>(); 

            foreach (var item in directory.GetFilesAndDirectories())
            {
                if (!item.IsDirectory)
                {
                    var fileClient = directory.GetFileClient(item.Name);
                    files.Add(new FileShareModel 
                    {
                        FileName = item.Name,
                        Url = fileClient.Uri.ToString()
                    });
                }
            }

            return View(files);
        }

        // POST: /FileShare/Upload
        [HttpPost]
        public IActionResult Upload(IFormFile file)
        {
            if (file != null && file.Length > 0)
            {
                var shareClient = new ShareClient(_connectionString, _shareName);
                shareClient.CreateIfNotExists();

                var directory = shareClient.GetRootDirectoryClient();
                var fileClient = directory.GetFileClient(file.FileName);

                fileClient.Create(file.Length);

                using (var stream = file.OpenReadStream())
                {
                    fileClient.UploadRange(
                        new Azure.HttpRange(0, file.Length),
                        stream
                    );
                }
            }
            return RedirectToAction(nameof(Index));
        }

        // GET: /FileShare/Delete?fileName=xyz.txt
        public IActionResult Delete(string fileName)
        {
            var shareClient = new ShareClient(_connectionString, _shareName);
            var directory = shareClient.GetRootDirectoryClient();

            var fileClient = directory.GetFileClient(fileName);
            fileClient.DeleteIfExists();

            return RedirectToAction(nameof(Index));
        }
    }
}
