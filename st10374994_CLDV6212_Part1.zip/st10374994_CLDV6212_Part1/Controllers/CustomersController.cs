﻿using Azure.Data.Tables;
using Microsoft.AspNetCore.Mvc;
using st10374994_CLDV6212_Part1.Models;

namespace st10374994_CLDV6212_Part1.Controllers
{
    public class CustomersController : Controller
    {
        private readonly string _connectionString;
        private readonly string _tableName = "CustomerProducts";

        public CustomersController(IConfiguration configuration)
        {
            _connectionString = configuration["AzureStorage:ConnectionString"];
        }

        // READ - Show all customers
        public IActionResult Index()
        {
            var tableClient = new TableClient(_connectionString, _tableName);
            var customers = tableClient.Query<CustomerEntity>(c => c.PartitionKey == "Customer").ToList();
            return View(customers);
        }

        // CREATE - Show form
        public IActionResult Create()
        {
            return View();
        }

        // CREATE - Save
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(CustomerEntity customer)
        {
            customer.PartitionKey = "Customer";
            customer.RowKey = Guid.NewGuid().ToString();

            var tableClient = new TableClient(_connectionString, _tableName);
            tableClient.AddEntity(customer);

            return RedirectToAction(nameof(Index));
        }

        // DETAILS
        public IActionResult Details(string partitionKey, string rowKey)
        {
            var table = new TableClient(_connectionString, _tableName);
            var customer = table.GetEntity<CustomerEntity>(partitionKey, rowKey).Value;
            return View(customer);
        }

        // EDIT - GET
        public IActionResult Edit(string partitionKey, string rowKey)
        {
            var table = new TableClient(_connectionString, _tableName);
            var customer = table.GetEntity<CustomerEntity>(partitionKey, rowKey).Value;
            return View(customer);
        }

        // EDIT - POST
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(CustomerEntity customer)
        {
            var table = new TableClient(_connectionString, _tableName);
            table.UpsertEntity(customer);
            return RedirectToAction(nameof(Index));
        }

        // DELETE - GET
        public IActionResult Delete(string partitionKey, string rowKey)
        {
            var table = new TableClient(_connectionString, _tableName);
            var customer = table.GetEntity<CustomerEntity>(partitionKey, rowKey).Value;
            return View(customer);
        }

        // DELETE - POST
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(CustomerEntity customer)
        {
            var table = new TableClient(_connectionString, _tableName);
            table.DeleteEntity(customer.PartitionKey, customer.RowKey);
            return RedirectToAction(nameof(Index));
        }
    }
}
