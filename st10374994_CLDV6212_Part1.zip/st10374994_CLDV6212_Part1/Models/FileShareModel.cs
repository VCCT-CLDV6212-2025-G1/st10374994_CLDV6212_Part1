﻿namespace st10374994_CLDV6212_Part1.Models
{
    public class FileShareModel
    {
        public string FileName { get; set; } = string.Empty;
        public string Url { get; set; } = string.Empty;
    }
}
