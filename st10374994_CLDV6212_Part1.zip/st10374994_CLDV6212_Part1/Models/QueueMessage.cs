﻿namespace st10374994_CLDV6212_Part1.Models
{
    public class QueueMessage
    {
        public string MessageId { get; set; }
        public string MessageText { get; set; }
        public DateTimeOffset? InsertionTime { get; set; }

    }
}
