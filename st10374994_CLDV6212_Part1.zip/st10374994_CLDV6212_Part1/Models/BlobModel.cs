﻿namespace st10374994_CLDV6212_Part1.Models
{
    public class BlobModel
    {
        public string FileName { get; set; }
        public string BlobUrl { get; set; }
    }
}
