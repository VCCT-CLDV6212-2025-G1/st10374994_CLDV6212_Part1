﻿using Azure.Data.Tables;
using Azure.Storage.Blobs;
using Azure.Storage.Queues;
using Azure.Storage.Files.Shares;

var builder = WebApplication.CreateBuilder(args);


builder.Services.AddControllersWithViews();


var connectionString = builder.Configuration["AzureStorage:ConnectionString"];
builder.Services.AddSingleton<TableServiceClient>(new TableServiceClient(connectionString));
builder.Services.AddSingleton<BlobServiceClient>(new BlobServiceClient(connectionString));
builder.Services.AddSingleton<QueueServiceClient>(new QueueServiceClient(connectionString));
builder.Services.AddSingleton<ShareServiceClient>(new ShareServiceClient(connectionString));

var app = builder.Build();


if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
